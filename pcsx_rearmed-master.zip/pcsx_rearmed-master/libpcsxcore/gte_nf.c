#define FLAGLESS
#include "gte.c"
