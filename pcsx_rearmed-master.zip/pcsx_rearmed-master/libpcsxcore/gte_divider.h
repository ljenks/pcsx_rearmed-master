u32 DIVIDE(s16 n, u16 d);
