
void plat_omap_init(void);
void plat_omap_finish(void);
void plat_omap_gvideo_open(void);

