void blit320_640(void *dst, const void *src, int unused);
void blit320_512(void *dst, const void *src, int unused);
void blit320_368(void *dst, const void *src, int unused);
