
void  cdrcimg_set_fname(const char *fname);
void *cdrcimg_get_sym(const char *sym);
