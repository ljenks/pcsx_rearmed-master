#define pcsx4all_prof_pause(...)
#define pcsx4all_prof_start_with_pause(...)
#define pcsx4all_prof_end_with_resume(...)
#define pcsx4all_prof_resume(...)
